// Google Analytics 4 helper utilities for Triangle Adventures.
// Replace G-FLVFVDD6YW with the real GA4 Measurement ID from Google Analytics.

export const GA_MEASUREMENT_ID = "G-FLVFVDD6YW";

const isAnalyticsReady = () =>
  typeof window !== "undefined" && typeof window.gtag === "function";

export function initGA() {
  if (typeof window === "undefined") return;

  if (!GA_MEASUREMENT_ID || GA_MEASUREMENT_ID === "G-FLVFVDD6YW") {
    console.warn(
      "GA4 is not active yet. Replace G-FLVFVDD6YW in src/utils/analytics.js with your GA4 Measurement ID."
    );
    return;
  }

  if (document.querySelector(`script[src*="gtag/js?id=${GA_MEASUREMENT_ID}"]`)) {
    return;
  }

  const script = document.createElement("script");
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
  document.head.appendChild(script);

  window.dataLayer = window.dataLayer || [];
  window.gtag = function gtag() {
    window.dataLayer.push(arguments);
  };

  window.gtag("js", new Date());

  // This is important for React Router / single page apps.
  // RouteChangeTracker sends page_view events manually on route changes.
  window.gtag("config", GA_MEASUREMENT_ID, {
    send_page_view: false,
  });
}

export function trackPageView(path, title = document.title) {
  if (!isAnalyticsReady()) return;

  window.gtag("event", "page_view", {
    page_path: path,
    page_title: title,
    page_location: window.location.href,
  });
}

export function trackEvent(eventName, params = {}) {
  if (!isAnalyticsReady()) return;

  window.gtag("event", eventName, {
    page_path: window.location.pathname,
    ...params,
  });
}

export function trackBookNowClick({ tourName, tourSlug, buttonLocation }) {
  trackEvent("book_now_click", {
    tour_name: tourName,
    tour_slug: tourSlug,
    button_location: buttonLocation,
    destination: "fareharbor",
  });
}

export function trackGiftCardClick({ buttonLocation } = {}) {
  trackEvent("gift_card_click", {
    button_location: buttonLocation,
    destination: "fareharbor",
  });
}

export function trackPhoneClick({ buttonLocation } = {}) {
  trackEvent("phone_click", {
    button_location: buttonLocation,
    contact_method: "phone",
  });
}

export function trackEmailClick({ buttonLocation } = {}) {
  trackEvent("email_click", {
    button_location: buttonLocation,
    contact_method: "email",
  });
}

export function trackTripadvisorClick({ buttonLocation } = {}) {
  trackEvent("tripadvisor_click", {
    button_location: buttonLocation,
    destination: "tripadvisor",
  });
}

export function trackInstagramClick({ buttonLocation, tourSlug, contentType = "profile" } = {}) {
  trackEvent("instagram_click", {
    button_location: buttonLocation,
    tour_slug: tourSlug,
    content_type: contentType,
    destination: "instagram",
  });
}
