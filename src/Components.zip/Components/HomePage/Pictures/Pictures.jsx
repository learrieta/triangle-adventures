import './pictures.css'
import hp1 from '../../../assets/Home/hp1.jpg'
import hp2 from '../../../assets/Home/hp2.jpg'
import hp3 from '../../../assets/Home/hp3.jpg'
import hp4 from '../../../assets/Home/hp4.jpg'
import hp5 from '../../../assets/Home/hp5.jpg'
import hp6 from '../../../assets/Home/hp6.png'
import hp7 from '../../../assets/Home/hp7.jpg'
import hp8 from '../../../assets/Home/hp8.jpg'
import hp9 from '../../../assets/Home/fooddrink.png'

const Pictures = () => {
  return (
    <section>
        <div className="container pt-4">
            <div className="text-center">
                <p className="tours--subtitle"><i className="fa-brands fa-instagram fa-xl" style={{color: '#f9b717'}}></i> triangle adventures</p>
                <div className="instagram--title">
                  <h4 >Use The Hashtag <span>#TriangleAdventures</span></h4>
                </div>
                <p className="tours--subtitle">For a chance to have your picture featured on our home page!</p>
            </div>
            <div className="row  ">
              
              <div className="col-lg-3 col-md-6 col-sm-12 my-2   ">
                <div className='image--item'>
                  <img src={hp1} alt="Triangle Adventures e-bike tour experience" title='clayton fun activities'  loading='lazy' className='img-fluid'/>
                </div>
                
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 my-2  ">
                <div className='image--item'>
                  <img src={hp2} alt="Triangle Adventures e-bike tour experience" loading="lazy" className="card--img"  style={{ height: '242px', width: '100%' }} />
                </div>
                
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 my-2  ">
                <div className='image--item'>
                  <img src={hp3} alt="Triangle Adventures e-bike tour experience" title='clayton fun activities'  loading='lazy' className='img-fluid'/>
                </div>
                
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 my-2  ">
                <div className='image--item'>
                  <img src={hp4} alt="Triangle Adventures e-bike tour experience" title='clayton fun activities'  loading='lazy' className='img-fluid'/>
                </div>
                
              </div>
              
              
              
            </div>
            <div className="row ">
              <div className="col-lg-3 col-md-6 col-sm-12 my-2  ">
                <div className='image--item'>
                  <img src={hp5} alt="Triangle Adventures e-bike tour experience" title='clayton fun activities'  loading='lazy' className='img-fluid'/>
                </div>
                
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 my-2  ">
                <div className='image--item'>
                  <img src={hp6} alt="Triangle Adventures e-bike tour experience" title='clayton fun activities'  loading='lazy' className='img-fluid'/>
                </div>
                
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 my-2  ">
                <div className='image--item'>
                  <img src={hp7} alt="Triangle Adventures e-bike tour experience" title='clayton fun activities'  loading='lazy' className='img-fluid'/>
                </div>
                
              </div>
              <div className="col-lg-3 col-md-6 col-sm-12 my-2  ">
                <div className='image--item'>
                  <img src={hp8} alt="Triangle Adventures e-bike tour experience" title='clayton fun activities'  loading='lazy' className='img-fluid'/>
                </div>
                
              </div>
              
            </div>
        </div>
    </section>    
  )
}

export default Pictures